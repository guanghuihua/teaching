2025年高考全国一卷数学真题 exam-zh 源码

文件说明：
1. 2025年高考全国一卷数学真题（原卷版）_exam-zh.tex
2. 2025年高考全国一卷数学真题（解析版）_exam-zh.tex
3. figures/：两份 TeX 使用的原题插图和解析插图
4. 两个同名 PDF：XeLaTeX 编译预览

编译环境：XeLaTeX
主要依赖：exam-zh、graphicx、booktabs、array、longtable、makecell、enumitem、geometry

编译命令（在本目录执行，建议各运行两遍）：
  xelatex "2025年高考全国一卷数学真题（原卷版）_exam-zh.tex"
  xelatex "2025年高考全国一卷数学真题（解析版）_exam-zh.tex"

注意：
- figures 文件夹必须与 TeX 文件放在同一目录。
- 已保留试题、选项、表格、插图、答案、分析和详解；原 DOCX 页眉中的店铺广告水印未写入试卷正文。
